"""
File: Architecture-independent Executors

Copyright (C) Microsoft Corporation
SPDX-License-Identifier: MIT
"""

# This is a placeholder - so far, we have no architecture-independent code in executors
